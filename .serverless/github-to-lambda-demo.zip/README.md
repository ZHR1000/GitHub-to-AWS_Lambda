# github-to-lambda-demo

This repo contains the source code from the YouTube video (https://www.youtube.com/watch?v=AmHZxULclLQ)